/*
 * resizable_events.js
 */
(function($) {

module("resizable: events");

test("start", function() {
	ok(false, "missing test - untested code is broken code.");
});

test("resize", function() {
	ok(false, "missing test - untested code is broken code.");
});

test("stop", function() {
	ok(false, "missing test - untested code is broken code.");
});

})(jQuery);
